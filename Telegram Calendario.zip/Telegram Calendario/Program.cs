﻿using Newtonsoft.Json;
using OpenQA.Selenium;
using OpenQA.Selenium.PhantomJS;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Telegram.Bot.Args;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.InlineQueryResults;
using Telegram.Bot.Types.InputMessageContents;
using Telegram.Bot.Types.ReplyMarkups;
using TelegramBot;

namespace Telegram.Bot.Examples.Echo
{
    class Program
    {
        private static string ManausCer;
        private static string ManausKey;
        private static string ManausPassword;

        private static string SumareCer;
        private static string SumareKey;
        private static string SumarePassword;
        /*
        Sato
        */
        private static readonly TelegramBotClient SATOBOT = new TelegramBotClient("273421799:AAHXaqEanFDQ1gUubGxDsnIjca7dL3FN3Y0");
        /*
        Teste
       */
      //  private static readonly TelegramBotClient SATOBOT = new TelegramBotClient("367333120:AAFw6_5TYG_ZoYa2h2YKdBHpKUwTyl4HW0I");
        static void Main(string[] args)
        {
            CalendarTelegram.CreateCalendar(2017, 3);
            Console.WriteLine("hi");

            StreamReader certificadoManaus =
                   new StreamReader("CertificadoManaus.txt");
            ManausCer = certificadoManaus.ReadLine();
            ManausKey = certificadoManaus.ReadLine();
            ManausPassword = certificadoManaus.ReadLine();
            certificadoManaus.Close();

            StreamReader certificadoSumare =
                   new StreamReader("CertificadoSumaré.txt");
            SumareCer = certificadoSumare.ReadLine();
            SumareKey = certificadoSumare.ReadLine();
            SumarePassword = certificadoSumare.ReadLine();
            certificadoSumare.Close();
            
        /*    SATOBOT.OnCallbackQuery += BotOnCallbackQueryReceived;
            SATOBOT.OnMessage += BotOnMessageReceived;
            SATOBOT.OnMessageEdited += BotOnMessageReceived;
            SATOBOT.OnInlineQuery += BotOnInlineQueryReceived;
            SATOBOT.OnInlineResultChosen += BotOnChosenInlineResultReceived;
            SATOBOT.OnReceiveError += BotOnReceiveError;

            var me = SATOBOT.GetMeAsync().Result;

            Console.Title = me.Username;

            SATOBOT.StartReceiving();*/
            Console.ReadLine();
            SATOBOT.StopReceiving();
        }

        private static void BotOnReceiveError(object sender, ReceiveErrorEventArgs receiveErrorEventArgs)
        {
            Debugger.Break();
        }

        private static void BotOnChosenInlineResultReceived(object sender, ChosenInlineResultEventArgs chosenInlineResultEventArgs)
        {
            Console.WriteLine($"Received choosen inline result: {chosenInlineResultEventArgs.ChosenInlineResult.ResultId}");
        }

        private static async void BotOnInlineQueryReceived(object sender, InlineQueryEventArgs inlineQueryEventArgs)
        {

        }

        private static async void BotOnMessageReceived(object sender, MessageEventArgs messageEventArgs)
        {
            var message = messageEventArgs.Message;

            if (message == null || message.Type != MessageType.TextMessage) return;

                if (message.Text.StartsWith("/Opcoes")) // send inline keyboard
                {
                    await SATOBOT.SendChatActionAsync(message.Chat.Id, ChatAction.Typing);

                    var keyboard = new InlineKeyboardMarkup(new[]
                    {
                        new[] 
                        {
                          //  new InlineKeyboardButton("Listar DI's","Listar DI's"),
                            new InlineKeyboardButton("Consultar NCM","NCM"),
                            new InlineKeyboardButton("Consultar DI","DI")
                        }
                    });

                 

                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "Escolha a opção",
                        replyMarkup: keyboard);
                }
            else if (message.Text == "/calendario")
            {
                
            }
            else if (message.Text.StartsWith("/ncm"))
            {
                if (message.Text == "/ncm")
                {
                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "Por favor digite o codigo NCM\nEx: /ncm29211999");
                }
                else if (message.Text.Length != 12)
                {
                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "NCM inválida");
                }
                else
                {
                    logComexAPINCM(message.Text.Substring(4), message.Chat.Id);
                }
              
            }

            else if (message.Text.StartsWith("/di"))
            {
                if (message.Text == "/di")
                {
                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "Por favor digite a DI\nEx: /di1617739857");
                }
                else if (message.Text.Length != 13)
                {
                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "DI inválida");
                }


                else
                {
                    var keyboard = new InlineKeyboardMarkup(new[]
                    {
                        new[]
                        {
                          //  new InlineKeyboardButton("Listar DI's","Listar DI's"),
                            new InlineKeyboardButton("HTB MAO","HTBMAODI"+message.Text.Substring(3)),
                            new InlineKeyboardButton("HTB SUM","HTBSUMDI"+message.Text.Substring(3))
                        }
                    });

                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "Escolha",
                        replyMarkup: keyboard);

                   
                }

            }

            else if (message.Text == "/sato")
            {
                var usage = @"/Opcoes - Mostrar opções de comando";
                await SATOBOT.SendTextMessageAsync(message.Chat.Id,usage ,
                      replyMarkup: new ReplyKeyboardRemove());
            }
        }

        private static async void BotOnCallbackQueryReceived(object sender, CallbackQueryEventArgs callbackQueryEventArgs)
        {
            var message = callbackQueryEventArgs.CallbackQuery.Message;

            Console.WriteLine(callbackQueryEventArgs.CallbackQuery.Data);

            


            if (callbackQueryEventArgs.CallbackQuery.Data.StartsWith("HTBMAODI"))
            {
                await SATOBOT.AnswerCallbackQueryAsync(callbackQueryEventArgs.CallbackQuery.Id,
                "Certificado da HTB Manaus escolhido", false
                , null, cacheTime: 0);

                consultaDI(callbackQueryEventArgs.CallbackQuery.Data.Substring(8), message.Chat.Id,"MAO");
            }
            else if (callbackQueryEventArgs.CallbackQuery.Data.StartsWith("HTBSUMDI"))
            {
                await SATOBOT.AnswerCallbackQueryAsync(callbackQueryEventArgs.CallbackQuery.Id,
               "Certificado da HTB Sumaré escolhido", false
               , null, cacheTime: 0);
                consultaDI(callbackQueryEventArgs.CallbackQuery.Data.Substring(8), message.Chat.Id, "SUM");
            }

            if (callbackQueryEventArgs.CallbackQuery.Data == "Listar DI's")
            {
                await SATOBOT.SendChatActionAsync(message.Chat.Id, ChatAction.Typing);
                SqlConnection connection = new SqlConnection("hue");
                SqlCommand command = new SqlCommand();

                command.Connection = connection;
                string query = "select DI from DI";
                command.CommandText = query;
                List<string> DIsString = new List<string>();

                

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    int count = 0;
                    while (reader.Read())
                    {
                        DIsString.Add(reader[0].ToString());
                    }

                    connection.Close();

                    InlineKeyboardButton[][] DIs = new InlineKeyboardButton[DIsString.Count][];
                    for (int i = 0; i < DIs.Length; i++)
                    {
                        DIs[i] = new InlineKeyboardButton[1];
                    }
                    //DIs[0] = new InlineKeyboardButton[DIsString.Count];
                    foreach (var item in DIsString)
                    {
                        DIs[count][0] = new InlineKeyboardButton(item,"DI: " +item);
                        count++;
                    }

                    var keyboard = new InlineKeyboardMarkup(DIs);

                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "Escolha a DI:",
                    replyMarkup: keyboard);
                    //await SATOBOT.SendTextMessageAsync(callbackQueryEventArgs.CallbackQuery.Message.Chat.Id, listaDIs);
                }
                catch (Exception err)
                {
                    connection.Close();
                    Console.WriteLine(err.Message);
                    Console.WriteLine(query);
                }
                
            }

            else if (callbackQueryEventArgs.CallbackQuery.Data.StartsWith("DI:"))
            {
                
                await SATOBOT.SendChatActionAsync(message.Chat.Id, ChatAction.Typing);
                SqlConnection connection = new SqlConnection("hue");
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                string query = "select Format(DataDI,'dd/MM/yyyy') as DataDI , DI , Canal from DI where DI = '" + callbackQueryEventArgs.CallbackQuery.Data.Substring(4)+"'";
                command.CommandText = query;
                string resposta = "";
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        resposta += "DI: "+ reader["DI"].ToString() + "\n";
                        resposta += "CANAL: " + reader["Canal"].ToString() + "\n";
                        resposta += "Data Declaração: " + reader["DataDI"].ToString();
                    }
                    connection.Close();
                    await SATOBOT.SendTextMessageAsync(callbackQueryEventArgs.CallbackQuery.Message.Chat.Id, resposta);
                }
                catch (Exception err)
                {
                    connection.Close();
                    Console.WriteLine(err.Message);
                    Console.WriteLine(query);
                }
            }
                          //Função em desenvolvimento

            if (callbackQueryEventArgs.CallbackQuery.Data == "NCM")
            {
                
                    await SATOBOT.SendTextMessageAsync(message.Chat.Id, "Digite /ncm + codigo do NCM \nEx: /ncm2921.19.99");
                
            }

            else if (callbackQueryEventArgs.CallbackQuery.Data == "DI")
            {

                await SATOBOT.SendTextMessageAsync(message.Chat.Id, "Digite /di + DI \nEx: /di1617739857");

            }







        }

        static async void logComexAPINCM(string stringncm , long ID)
        {
            try
            {
                stringncm = stringncm.Replace("/", "").Replace("-", "").Replace(".", "").Replace(" ", "").Trim();
                stringncm = stringncm.Insert(4, ".");
                stringncm = stringncm.Insert(7, ".");
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
                return;
            }
            
            await SATOBOT.SendChatActionAsync(ID, ChatAction.Typing);
            try
            {
                string resposta = "";

                var baseAddress = new Uri("http://api.logcomex.net");

                using (var httpClient = new HttpClient { BaseAddress = baseAddress })
                {

                    using (var response = await httpClient.GetAsync("/v3/ncm/" + stringncm + "?api_token=uWW0FWg3iDJx1EtuILIzapxli882d2hdntYbG7swrnppNDf9qvdfbxaXJ9Z9"))
                    {

                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine(responseData);
                        NCM ncm = JsonConvert.DeserializeObject<NCM>(responseData);
                        resposta += "COFINS: " + ncm.aliquota_cofins + "\n";
                        Console.WriteLine("COFINS: " + ncm.aliquota_cofins);
                        resposta += "II: " + ncm.aliquota_ii + "\n";
                        Console.WriteLine("II: " + ncm.aliquota_ii);
                        resposta += "IPI: " + ncm.aliquota_ipi + "\n";
                        Console.WriteLine("IPI: " + ncm.aliquota_ipi);
                        resposta += "PIS: " + ncm.aliquota_pis;
                        Console.WriteLine("PIS: " + ncm.aliquota_pis);
                        foreach (var item in ncm.tratamento)
                        {
                            resposta += "\n\nTIPO TRATAMENTO: " + item.tipo +"\n";
                            Console.WriteLine(item.tipo);
                            foreach (var anuencia in item.anuentes)
                            {
                                resposta += "ANUENTE: " + anuencia.anuente;
                                Console.WriteLine(anuencia.anuente);
                            }
                        }
                    }
                }
                await SATOBOT.SendTextMessageAsync(ID, resposta);
            }
            catch (HttpRequestException err)
            {
                Console.WriteLine(err.Message);
                await SATOBOT.SendTextMessageAsync(ID, "API do LogComex não está funcionando");
            }


            catch (Exception err)
            {
                Console.WriteLine(err.Message);
                await SATOBOT.SendTextMessageAsync(ID, "API do LogComex não está funcionando");
            }

        }

        static async void consultaDI(string stringDI, long ID , string certificado)
        {
            stringDI = stringDI.Replace("/", "").Replace("-", "").Replace(" ","").Trim();
            var service = PhantomJSDriverService.CreateDefaultService(Environment.CurrentDirectory, "phantomjs.exe");
            if (certificado == "MAO")
            {
                service = PhantomJSDriverService.CreateDefaultService(Environment.CurrentDirectory, "phantomjs.exe");
                service.AddArguments(@"--ssl-client-certificate-file="+ManausCer, @"--ssl-client-key-file="+ManausKey, "--ssl-client-key-passphrase="+ManausPassword, "--webdriver-loglevel=NONE");
            }
            else if (certificado == "SUM")
            {
                service = PhantomJSDriverService.CreateDefaultService(Environment.CurrentDirectory, "phantomjs.exe");
                service.AddArguments(@"--ssl-client-certificate-file="+SumareCer, @"--ssl-client-key-file="+SumareKey, "--ssl-client-key-passphrase="+SumarePassword, "--webdriver-loglevel=NONE");   
            }
            await SATOBOT.SendChatActionAsync(ID, ChatAction.Typing);

            PhantomJSDriver ff = null;
            try
            {
                
                ff = new PhantomJSDriver(service);
                
                ff.Navigate().GoToUrl("https://www1c.siscomex.receita.fazenda.gov.br/impdespacho-web-7/AcompanharSituacaoDespachoMenu.do");
                ff.FindElementById("nrDeclaracao").Click();
                ff.FindElementById("nrDeclaracao").SendKeys(stringDI);
                ff.FindElement(By.CssSelector("#botoes > input.button")).Click();

                DI DI = new DI(stringDI);


                string di = DI.DIFormatada;
                IWebElement diatual = ff.FindElementById(DI.Di);
                ff.FindElementByLinkText(di).Click();
                IWebElement status = ff.FindElementById("tr_" + DI.Di);
                string situacao = status.FindElement(By.XPath("(.//td)[2]")).Text;

                DI.Canal = ff.FindElementByXPath("//table[@id='TABLE_1']/tbody/tr[3]/td[3]").Text;

                DI.Status = situacao;

                Console.WriteLine(DI.Status);
                Console.WriteLine(DI.Canal);
                string resposta = "";

                resposta = "DI: " + DI.DIFormatada + "\nStatus: " + DI.Status + "\nCanal: " + DI.Canal;
                await SATOBOT.SendTextMessageAsync(ID, resposta);
                ff.Quit();
                
            }

            catch (Exception err)
            {
                Console.WriteLine(err.Message);
                await SATOBOT.SendTextMessageAsync(ID, "Falha em consultar DI");
                try
                {
                    ff.SwitchTo().Alert().Dismiss();
                }
                catch (Exception)
                {
                    
                }
                ff.Quit();
            }

           
        }
    }
}