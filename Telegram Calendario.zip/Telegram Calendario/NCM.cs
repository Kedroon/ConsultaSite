﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelegramBot
{
    public class Anuente
    {
        public object anuente { get; set; }
    }

    public class Tratamento
    {
        public object tipo { get; set; }
        public List<Anuente> anuentes { get; set; }
    }

    public class NCM
    {
        public string aliquota_ii { get; set; }
        public string aliquota_ipi { get; set; }
        public string aliquota_pis { get; set; }
        public string aliquota_cofins { get; set; }
        public bool cide { get; set; }
        public bool anti_dumping { get; set; }
        public List<Tratamento> tratamento { get; set; }
    }

}
