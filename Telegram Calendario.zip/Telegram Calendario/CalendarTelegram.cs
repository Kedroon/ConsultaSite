﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;

namespace TelegramBot
{
    class CalendarTelegram
    {
        public static InlineKeyboardMarkup CreateCalendar(int year , int month)
        {
            
            
            DateTime data = new DateTime(year, month, 1);
            DateTime makeData = new DateTime(year, month, 1);
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar calendario = dfi.Calendar;
            
            char[] weekDays = new char[7] { 'M', 'T', 'W', 'R', 'F', 'S', 'U' };
            List<List<int>> calendar = new List<List<int>>();
            Console.WriteLine(calendario.GetWeekOfYear(makeData, CalendarWeekRule.FirstDay, DayOfWeek.Sunday));

            while (makeData.Month == data.Month)
            {
                int semana = calendario.GetWeekOfYear(makeData, CalendarWeekRule.FirstDay, DayOfWeek.Sunday);
                List<int> listaSemana = new List<int>();

                while (semana == calendario.GetWeekOfYear(makeData, CalendarWeekRule.FirstDay, DayOfWeek.Sunday) && makeData.Month == data.Month)
                {
                    listaSemana.Add(makeData.Day);
                    makeData = makeData.AddDays(1);
                }
                calendar.Add(listaSemana);

                while (calendar[0].Count != 7)
                {
                    calendar[0].Insert(0, 0);
                }
                int ultimaSemana = calendar.Count - 1;
                while (calendar[ultimaSemana].Count != 7)
                {
                    calendar[ultimaSemana].Add(0);
                }

            }
            int linhasCountKeyboard = 1;

            InlineKeyboardButton[] weekDaysButtons = new InlineKeyboardButton[weekDays.Length];
            for (int j = 0; j < weekDaysButtons.Length; j++)
            {
                weekDaysButtons[j] = new InlineKeyboardButton(weekDays[j].ToString(),"ignore");
            }
            linhasCountKeyboard++;
            
            //keyboard.InlineKeyboard[2] = weekDaysButtons;

            int i = 0;
            List<InlineKeyboardButton[]> listaSemanas = new List<InlineKeyboardButton[]>();
            foreach (var week in calendar)
            {
                InlineKeyboardButton[] daysOfWeek = new InlineKeyboardButton[7];
                foreach (var day in week)
                {
                    if (day == 0)
                    {
                        daysOfWeek[i] = new InlineKeyboardButton(day.ToString(), "ignore");
                    }
                    else
                    {
                        daysOfWeek[i] = new InlineKeyboardButton(day.ToString(), day.ToString());
                    }
                    Console.Write(day + " ");
                }
                // keyboard.InlineKeyboard[i+3] = daysOfWeek;
                
                Console.WriteLine("");
                i++;
                linhasCountKeyboard++;
                listaSemanas.Add(daysOfWeek);
            }
            InlineKeyboardButton[] botoesFinal = new InlineKeyboardButton[3];
            botoesFinal[0] = new InlineKeyboardButton("<", "previous-month");
            botoesFinal[1] = new InlineKeyboardButton(" ", "ignore");
            botoesFinal[2] = new InlineKeyboardButton(">", "next-month");
            linhasCountKeyboard += 3;
            //  keyboard.InlineKeyboard[i] = botoesFinal;
            InlineKeyboardButton[][] botoesConcatenados = new InlineKeyboardButton[linhasCountKeyboard][];
            botoesConcatenados[0] = new InlineKeyboardButton[1];
            botoesConcatenados[0][0] = new InlineKeyboardButton(data.ToString("MMMM") +" "+ data.Year.ToString());

            botoesConcatenados[1] = new InlineKeyboardButton[weekDays.Length];
            botoesConcatenados[1] = weekDaysButtons;


            int countBotoesConcatenados = 2;
            foreach (var week in listaSemanas)
            {
                botoesConcatenados[countBotoesConcatenados] = new InlineKeyboardButton[7];
                botoesConcatenados[countBotoesConcatenados] = week;
                countBotoesConcatenados++;
            }
            botoesConcatenados[countBotoesConcatenados] = new InlineKeyboardButton[3];
            botoesConcatenados[countBotoesConcatenados] = botoesFinal;

            foreach (var linha in botoesConcatenados)
            {
                foreach (var botao in linha)
                {
                    Console.WriteLine(botao.Text);
                }
            }
            InlineKeyboardMarkup keyboard = new InlineKeyboardMarkup(botoesConcatenados);
            return keyboard;
        }
    }
}
