﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelegramBot
{
    class DI
    {
        public string Fatura = "";
        public string Di = "";
        public string DIFormatada;
        public string Canal = "";
        public string Status = "";
        public string Armazem = "";
        public string Dias = "";
        public string DataDesembaraço = "";
        public string Processo = "";
        public string Datadeclaracao = "";
        public string DataChegada = "";
        public string Modelo = "";
        public string Fornecedor = "";
        public string Motivo = "";

        public DI(string di)
        {
            Di = di;
            string ditemp = Di;
            ditemp = string.Format(di.Substring(0, 2) + "{0}" + di.Substring(2, 7) + "{1}" + di.Substring(9, 1), "/", "-");
            DIFormatada = ditemp;
        }
    }
}
