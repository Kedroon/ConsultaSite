﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace serverSocket
{
    class Program
    {
        static Listener listener;
        static void Main(string[] args)
        {
            listener = new Listener(1994);
            listener.SocketAccepted += Listener_SocketAccepted;
            listener.Start();
            Console.Read();

        }

        private static void Listener_SocketAccepted(Socket e)
        {
            Client client = new Client(e);
            client.Received += Client_Received;
            client.Disconnected += Client_Disconnected;
            Console.WriteLine("Client connected: "+client.ID + " " + client.EndPoint);
        }

        private static void Client_Disconnected(Client sender)
        {
            Console.WriteLine("Disconnected "+ sender.ID + " " + sender.EndPoint);
        }

        private static void Client_Received(Client sender, byte[] data)
        {
            Console.WriteLine("Message: " + Encoding.Default.GetString(data));
        }

        
    }
}
