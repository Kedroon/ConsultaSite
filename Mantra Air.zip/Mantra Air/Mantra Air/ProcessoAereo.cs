﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mantra_Air
{
    class ProcessoAereo
    {
        public string id;
        public string master;
        public string house;
    }
}
