﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Open3270;
using System.Diagnostics;

namespace Mantra_Air
{
    class Program
    {
        static string login;
        static string senha;
        static string ip;
        static string port;
        static void Main(string[] args)
        {
            try
            {
                StreamReader certificadoManaus =
                   new StreamReader(@"C:\MantraAir\parametros.txt");
                login = certificadoManaus.ReadLine();
                Console.WriteLine(login);
                senha = certificadoManaus.ReadLine();
                Console.WriteLine(senha);
                ip = certificadoManaus.ReadLine();
                port = certificadoManaus.ReadLine();
                certificadoManaus.Close();
            }
            catch (Exception err)
            {
                Console.WriteLine(err);
                Console.Read();
                return;
            }

            Run();
            Console.Read();


        }

        public static void Run()
        {
            List<ProcessoAereo> processos = new List<ProcessoAereo>();
            SqlConnection connection = new SqlConnection(Resource1.connectionStringProducao);
            string query = "select id , master , house from FollowUpAgentesAir where master is not null and house is not null";
            SqlCommand command = new SqlCommand(query,connection);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    ProcessoAereo processo = new ProcessoAereo() { id = reader[0].ToString(), master = reader[1].ToString(),house = reader[2].ToString()};
                    processos.Add(processo);
                }
                connection.Close();
            }
            catch (Exception)
            {
                connection.Close();
            }
            Console.WriteLine(processos[0].master +" "+processos[0].house);
           // Console.Read();
            TNEmulator tnEmulator = new TNEmulator();
            tnEmulator.Audit = new Audit();
            tnEmulator.Debug = false;
            tnEmulator.Config.RefuseTN3270E = false;
            tnEmulator.Config.FastScreenMode = false;
            tnEmulator.UseSSL = false;
            tnEmulator.Connect(ip, Convert.ToInt16(port), null);
            Console.WriteLine(tnEmulator.ToString());
            tnEmulator.ShowFields();
            if (!tnEmulator.WaitForText(28, 0, "REDE", 4000))
            {
                Console.WriteLine("Conexão ao SERPRO Falhou!");
            }
            else
            {
                Console.WriteLine("Conectado ao SERPRO!");
                tnEmulator.SendKey(false, TnKey.Enter, 500);
                if (!tnEmulator.WaitForText(1, 15, "CODIGO", 4000))
                {
                    tnEmulator.ShowFields();
                }
                else
                {
                    Console.WriteLine("OK, efetuando login no SISCOMEX!");
                    tnEmulator.SetCursor(11, 15);
                    tnEmulator.SetText(login);
                    tnEmulator.SetCursor(11, 16);
                    tnEmulator.SetText(senha);
                    tnEmulator.SetCursor(11, 17);
                    tnEmulator.SetText("siscomex");
                    tnEmulator.ShowFields();
                    tnEmulator.SendKey(false, TnKey.Enter, 500);
                    if (tnEmulator.WaitForText(11, 22, "SENHA INCORRETA", 2000))
                    {
                        Console.WriteLine("SENHA INCORRETA!\nEncerrando Aplicativo!");
                        tnEmulator.ShowFields();
                        tnEmulator.Close();
                    }
                    else if (tnEmulator.WaitForText(11, 22, "VOCE JA ESTA UTILIZANDO ESTE SISTEMA EM OUTRO TERMINAL.", 2000))
                    {
                        Console.WriteLine("TERMINAL EM USO!\nEncerrando Aplicativo!");
                        tnEmulator.ShowFields();
                        tnEmulator.Close();
                    }
                    else if (tnEmulator.WaitForText(5, 0, "SISCOMEX", 4000))
                    {
                        tnEmulator.ShowFields();
                        tnEmulator.SetCursor(12, 11);
                        tnEmulator.SendKey(false, TnKey.Enter,500);
                        tnEmulator.Refresh(true, 1000);
                        tnEmulator.SetCursor(14, 7);
                        tnEmulator.ShowFields();
                        tnEmulator.SendKey(false, TnKey.Enter, 500);
                        tnEmulator.Refresh(true, 1000);
                        if (tnEmulator.CurrentScreenXML.GetXMLText().Contains("EXISTEM NOVAS NOTICIAS"))
                        {
                            tnEmulator.SetCursor(40, 15);
                            tnEmulator.SetText("N");
                            tnEmulator.SendKey(true, TnKey.Enter, 500);
                        }
                        tnEmulator.ShowFields();
                        tnEmulator.SetCursor(30, 11);
                      //  tnEmulator.SetText(processos[50].master);
                        tnEmulator.SetText("54924641411");
                        tnEmulator.SetCursor(30, 13);
                     //   tnEmulator.SetText(processos[50].house);
                        tnEmulator.SetText("42H0008023");
                        tnEmulator.ShowFields();
                        tnEmulator.SendKey(false, TnKey.Enter, 500);
                        tnEmulator.Refresh(true, 1000);
                        tnEmulator.ShowFields();
                        if (tnEmulator.CurrentScreenXML.GetXMLText().Contains("DOCUMENTO DE CARGA NAO REGISTRADO NO SISTEMA"))
                        {
                            Console.WriteLine("NAO ENCONTRADO");
                        }
                        else
                        {
                            /*string chegada = tnEmulator.GetText(19, 12, 18);
                            Console.WriteLine(chegada);
                            string terminal = tnEmulator.GetText(76, 12, 1);
                            Console.WriteLine(terminal);
                            string dtaEC = tnEmulator.GetText(30, 13, 10);
                            Console.WriteLine(dtaEC);
                            string dtaECData = tnEmulator.GetText(63, 13, 10);
                            Console.WriteLine(dtaECData);
                            string status1 = tnEmulator.GetText(62, 14, 16);
                            string status2 = tnEmulator.GetText(62, 15, 16);
                            string status3 = tnEmulator.GetText(62, 16, 16);
                            string status4 = tnEmulator.GetText(62, 17, 16);
                            string status5 = tnEmulator.GetText(62, 18, 16);
                            Console.WriteLine(status1);
                            Console.WriteLine(status2);
                            Console.WriteLine(status3);
                            Console.WriteLine(status4);
                            Console.WriteLine(status5);*/
                            Debug.WriteLine(tnEmulator.CurrentScreenXML.GetXMLText());

                            string terminal = "";
                            foreach (var item in tnEmulator.CurrentScreenXML.Fields)
                            {
                                // Console.WriteLine(item.Text);
                                if (item.Text != null && item.Text.IndexOf("CHEGADA") != -1)
                                {
                                    string chegada = tnEmulator.GetText(19, item.Location.top, 18);
                                    terminal = tnEmulator.GetText(76, item.Location.top, 1);

                                    Console.WriteLine(chegada);
                                    Console.WriteLine(terminal);
                                }
                                else if (item.Text != null && item.Text.IndexOf("DESEMB") != -1)
                                {
                                    string desembaracado = tnEmulator.GetText(19, item.Location.top, 18);
                                    Console.WriteLine(desembaracado);
                                }
                                else if (item.Text != null && item.Text.IndexOf("VISADO") != -1)
                                {
                                    string visado = tnEmulator.GetText(19, item.Location.top, 18);
                                    Console.WriteLine(visado);
                                }
                            }

                            if (tnEmulator.GetText(74,3,2) == "02")
                            {
                                Console.WriteLine("Pagina 02");
                                tnEmulator.SendKey(false, TnKey.Enter, 500);
                                tnEmulator.Refresh(true, 1000);
                                tnEmulator.ShowFields();

                                foreach (var item in tnEmulator.CurrentScreenXML.Fields)
                                {
                                    // Console.WriteLine(item.Text);
                                    if (item.Text != null && item.Text.IndexOf("CHEGADA") != -1)
                                    {
                                        string chegada = tnEmulator.GetText(19, item.Location.top, 18);
                                        terminal = tnEmulator.GetText(76, item.Location.top, 1);

                                        Console.WriteLine(chegada);
                                        Console.WriteLine(terminal);
                                    }
                                    else if (item.Text != null && item.Text.IndexOf("DESEMB") != -1)
                                    {
                                        string desembaracado = tnEmulator.GetText(19, item.Location.top, 18);
                                        Console.WriteLine(desembaracado);
                                    }
                                    else if (item.Text != null && item.Text.IndexOf("VISADO") != -1)
                                    {
                                        string visado = tnEmulator.GetText(19, item.Location.top, 18);
                                        Console.WriteLine(visado);
                                    }
                                }
                            }

                            
                        }
                       
                    }
                }
            }
        }


    }
}
